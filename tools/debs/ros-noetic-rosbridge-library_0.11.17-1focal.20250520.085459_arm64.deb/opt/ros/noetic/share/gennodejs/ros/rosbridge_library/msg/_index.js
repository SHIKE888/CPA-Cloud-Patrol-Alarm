
"use strict";

let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestHeaderArray = require('./TestHeaderArray.js');
let TestHeader = require('./TestHeader.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let TestUInt8 = require('./TestUInt8.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestChar = require('./TestChar.js');
let Num = require('./Num.js');

module.exports = {
  TestHeaderTwo: TestHeaderTwo,
  TestHeaderArray: TestHeaderArray,
  TestHeader: TestHeader,
  TestTimeArray: TestTimeArray,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  TestUInt8: TestUInt8,
  TestDurationArray: TestDurationArray,
  TestChar: TestChar,
  Num: Num,
};
